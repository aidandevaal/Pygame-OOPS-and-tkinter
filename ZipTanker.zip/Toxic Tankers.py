import pygame 
import os
import time
import random
pygame.init()
lives=3
vel=3
win = pygame.display.set_mode((700, 480))
w = 500
h = 373
k = 100
l = 373
bg = pygame.image.load('play.png')
pygame.display.set_caption("Toxic Tankers") 
clock = pygame.time.Clock()
walkRight = [pygame.image.load('pubg.png'), ('pubgr')]
walkLeft = [pygame.image.load('pubg2.png'), ('pubg2l')]
score = 0
time = 0
seconds = 0
num_of_enemies = 20
enemyImg = []
respawn = False
isJump = False

for i in range(num_of_enemies):
        enemyImg.append(pygame.image.load('Sprite 1.png'))

_image_library = {}                     
def get_image(path):
        global _image_library
        image = _image_library.get("pubg.png")      
        if image == None:
                canonicalized_path = path.replace('/', os.sep).replace('\\', os.sep)
                image = pygame.image.load(canonicalized_path)
                _image_library[path] = image
        return image

_image_library = {}                     
def get_image(path):
        global _image_library
        image = _image_library.get("pubg2.png")      
        if image == None:
                canonicalized_path = path.replace('/', os.sep).replace('\\', os.sep)
                image = pygame.image.load(canonicalized_path)
                _image_library[path] = image
        return image

class player(object):        
        def __init__(self,x,y,width,height):
                self.x = w
                self.y = h
                self.width = width
                self.height = height
                self.vel = 5
                self.isJump = False
                self.left = False
                self.right = False
                self.walkCount = 0
                self.jumpCount = 10
                self.standing = True
                self.hitbox = (self.x + 17, self.y + 11, 29, 52)

        def draw(self, win):
                if self.walkCount + 1 >= 27:
                        self.walkCount = 0
                
                if not(self.standing):
                        if self.left:
                                win.blit(walkLeft[self.walkCount//4000], (self.x,self.y))
                                self.walkCount += 1
                        elif self.right:
                                win.blit(walkRight[self.walkCount//4000], (self.x,self.y))
                                self.walkCount +=1
                else:
                        if self.right:
                                win.blit(walkRight[0], (self.x, self.y))
                        else:
                                win.blit(walkLeft[0], (self.x, self.y))
                self.hitbox = (self.x + 17, self.y + 11, 29, 52)
        
        def hit(self):
                self.isJump = False
                self.jumpCount = 10
                self.x = 100
                self.y = 410
                self.walkCount = 0
                font1 = pygame.font.SysFont('comicsans', 100)
                text = font1.render('-1 LIFE', 1, (255,0,0))
                win.blit(text, (250 - (text.get_width()/2),200))
                pygame.display.update()
                i = 0
                while i < 200:
                        pygame.time.delay(10)
                        i += 1
                        for event in pygame.event.get():
                                if event.type == pygame.QUIT:
                                        i = 201
                                        pygame.quit()


class projectiles(object):                                                                                                  
        def __init__(self,x,y,radius,color,facing):
                self.x = x
                self.y = y
                self.radius = radius
                self.color = color
                self.facing = facing
                self.vel = 8 * facing

        def draw(self,win):
                pygame.draw.circle(win, self.color, (self.x,self.y), self.radius)

class enemy(object):
        win.blit(enemyImg[i], (k, l))
        walkRight = [pygame.image.load('Sprite 1.png')]
        walkLeft = [pygame.image.load('Sprite 2.png')]
        def __init__(self, x, y, width, height, end):
                self.x = k
                self.y = l
                self.width = width
                self.height = height
                self.end = end
                self.path = [self.x, self.end]
                self.walkCount = 0
                self.vel = 3
                self.hitbox = (self.x + 17, self.y + 2, 31, 57)
                self.lives = 5
                self.visible = True

        def draw(self,win):
                self.move()
                if self.visible:
                        if self.walkCount + 1 >= 33:
                                self.walkCount = 0

                        if self.vel > 0:
                                win.blit(self.walkRight[self.walkCount //4000], (self.x, self.y))
                                self.walkCount += 1
                        else:
                                win.blit(self.walkLeft[self.walkCount //4000], (self.x, self.y))
                                self.walkCount += 1

                        pygame.draw.rect(win, (255,0,0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
                        pygame.draw.rect(win, (0,128,0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.lives)), 10))
                        self.hitbox = (self.x + 17, self.y + 2, 31, 57)

        def move(self):
                if self.vel > 0:
                        if self.x + self.vel < self.path[1]:
                                self.x += self.vel
                        else:
                                self.vel = self.vel * -1
                                self.walkCount = 0
                else:
                        if self.x - self.vel > self.path[0]:
                                self.x += self.vel
                        else:
                                self.vel = self.vel * -1
                                self.walkCount = 0

        def hit(self):
                if self.lives > 0:
                        self.lives -= 1
                else:
                        zombie.x = 699
                        self.lives = 5
                print('hit')

        def hit2(self):
                if self.lives > 0:
                        self.lives -= 1
                else:
                        zombie2.x = 1
                        self.lives = 5
                print('hit')

        def hit3(self):
                if self.lives > 0:
                        self.lives -= 1
                else:
                        zombie3.x = 1
                        self.lives = 5
                print('hit')

def num_of_zombies(object):
        def __init__(self, x, y, width, height, num):
                self.x = x
                self.y = y
                self.width = width
                self.height = height
                self.num = num

def redrawGameWindow():                                                                                                 
        win.blit(bg, (0,0))
        text = font.render('Lives: ' + str(lives), 1, (0,0,0))
        win.blit(text, (350, 10))
        man.draw(win)
        zombie.draw(win)
        zombie2.draw(win)
        for bullet in bullets:
                bullet.draw(win)

        pygame.display.update()        
                 
run = True
font = pygame.font.SysFont('comicsans', 30, True)
man = player(500, 373, 64, 64)
zombie = enemy(1, 385, 64, 64, 700)
zombie2 = enemy(699, 385, 64, 64, 700)
zombie3 = enemy(699, 385, 64, 64, 700)
shootLoop = 0
bullets = []
num_of_zombies = 1
gameover = False

while run:

        if zombie.visible == True:
                if man.hitbox[1] < zombie.hitbox[1] + zombie.hitbox[3] and man.hitbox[1] + man.hitbox[3] > zombie.hitbox[1]:
                        if man.hitbox[0] + man.hitbox[2] > zombie.hitbox[0] and man.hitbox[0] < zombie.hitbox[0] + zombie.hitbox[2]:
                                man.hit()
                                man.x = 350
                                man.y = 373
                                zombie.x = 699
                                zombie2.x = -30
                                zombie3.x = 699
                                lives -= 1
                                text = font.render('Lives: ' + str(lives), 1, (0,0,0))
                                print(text)
                                if lives == 0:
                                        print("You Died --------- Your Score: ", score)
                                        pygame.time.delay(4000000)

        if zombie2.visible == True:
                if man.hitbox[1] < zombie2.hitbox[1] + zombie2.hitbox[3] and man.hitbox[1] + man.hitbox[3] > zombie2.hitbox[1]:
                        if man.hitbox[0] + man.hitbox[2] > zombie2.hitbox[0] and man.hitbox[0] < zombie2.hitbox[0] + zombie2.hitbox[2]:
                                man.hit()
                                man.x = 350
                                man.y = 373
                                zombie.x = -30
                                zombie2.x = 699
                                zombie3.x = 699
                                lives -= 1
                                text = font.render('Lives: ' + str(lives), 1, (0,0,0))
                                print(text)
                                if lives == 0:
                                        print("You Died --------- Your Score: ", score)
                                        pygame.time.delay(4000000)

        if zombie3.visible == True:
                if man.hitbox[1] < zombie3.hitbox[1] + zombie3.hitbox[3] and man.hitbox[1] + man.hitbox[3] > zombie3.hitbox[1]:
                        if man.hitbox[0] + man.hitbox[2] > zombie3.hitbox[0] and man.hitbox[0] < zombie3.hitbox[0] + zombie3.hitbox[2]:
                                man.hit()
                                man.x = 350
                                man.y = 373
                                zombie.x = 1
                                zombie2.x = 699
                                zombie3.x = 699
                                lives -= 1
                                text = font.render('Lives: ' + str(lives), 1, (0,0,0))
                                print(text)
                                if lives == 0:
                                        print("You Died --------- Your Score: ", score)
                                        pygame.time.delay(4000000)

        if shootLoop > 0:
                shootLoop += 1
        if shootLoop > 3:
                shootLoop = 0

        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        run = False

        for bullet in bullets:
                if bullet.y - bullet.radius < zombie.hitbox[1] + zombie.hitbox[3] and bullet.y + bullet.radius > zombie.hitbox[1]:
                        if bullet.x + bullet.radius > zombie.hitbox[0] and bullet.x - bullet.radius < zombie.hitbox[0] + zombie.hitbox[2]:
                                zombie.hit()
                                score += 5
                                bullets.pop(bullets.index(bullet))

        for bullet in bullets:
                if bullet.y - bullet.radius < zombie2.hitbox[1] + zombie2.hitbox[3] and bullet.y + bullet.radius > zombie2.hitbox[1]:
                        if bullet.x + bullet.radius > zombie2.hitbox[0] and bullet.x - bullet.radius < zombie2.hitbox[0] + zombie2.hitbox[2]:
                                zombie.hit2()
                                score += 5
                                bullets.pop(bullets.index(bullet))

        for bullet in bullets:
                if bullet.y - bullet.radius < zombie3.hitbox[1] + zombie3.hitbox[3] and bullet.y + bullet.radius > zombie3.hitbox[1]:
                        if bullet.x + bullet.radius > zombie3.hitbox[0] and bullet.x - bullet.radius < zombie3.hitbox[0] + zombie3.hitbox[2]:
                                zombie.hit3()
                                score += 5
                                bullets.pop(bullets.index(bullet))

                if bullet.x < 700 and bullet.x > 0:
                        bullet.x += bullet.vel
                else:
                        bullets.pop(bullets.index(bullet))

        pressed = pygame.key.get_pressed()
        if pressed[pygame.K_SPACE] and shootLoop == 0:
                if man.left:
                        facing = -1
                else:
                        facing = 1
                        
                if len(bullets) < 5:
                        bullets.append(projectiles(round(man.x + man.width //2), round(man.y + man.height //2), 6, (0,0,0), facing))

                shootLoop = 1
        
        if pressed[pygame.K_a] and man.x > man.vel:
                man.x -= man.vel
                man.left = True
                man.right = False
                man.standing = False
        elif pressed[pygame.K_d] and man.x < 700 - man.width - man.vel:
                man.x += man.vel
                man.right = True
                man.left = False
                man.standing = False
        else:
                man.standing = True
                man.walkCount = 0

        if not(man.isJump):
                if pressed[pygame.K_w]:
                        man.isJump = True
                        man.right = False
                        man.left = False
                        man.walkCount = 0
        else:
                if man.jumpCount >= -10:
                        neg = 1
                        if man.jumpCount < 0:
                                neg = -1
                        man.y -= (man.jumpCount ** 2) * 0.5 * neg
                        man.jumpCount -= 1
                else:
                        man.isJump = False
                        man.jumpCount = 10
                
       
        redrawGameWindow()

        clock.tick(30)

pygame.quit()
        
